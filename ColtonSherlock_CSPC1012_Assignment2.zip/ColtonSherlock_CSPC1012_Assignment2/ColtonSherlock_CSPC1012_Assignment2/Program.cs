﻿/// <summary>
/// Description  : This programs estimates the total cost of a road trip
/// Author       : Colton Sherlock
/// Date         : 2026-03-13
/// </summary>


using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace ColtonSherlock_CSPC1012_Assignment2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const double YOUR_CAR_EFFICIENCY = 11.9;
            const double FRIEND_CAR_EFFICIENCY = 8.7;
            const double MIN_GAS_PRICE = 1.40;
            const double MAX_GAS_PRICE = 2.00;

            Random random = new Random();
            double gasPrice = random.NextDouble() * (MAX_GAS_PRICE - MIN_GAS_PRICE) + MIN_GAS_PRICE;

            bool continueProgram = true; 

            while (continueProgram)
            {
                try
                {
                    int distanceKm = 0;

                    Console.Write("Enter total trip distance in Km");
                    while (!int.TryParse(Console.ReadLine(), out distanceKm) || distanceKm <= 0)
                    {
                        Console.WriteLine("Invalid input. Please enter a positive whole number");
                        Console.Write("Enter total trip distance in kilometers: ");
                    }

                    Console.Write("Will you use your vehicle or your friends? (y/f): ");
                    string vehicleChoice = Console.ReadLine().ToLower();

                    double fuelEfficiency;

                    if (vehicleChoice == "y")
                    {
                        fuelEfficiency = YOUR_CAR_EFFICIENCY;
                    }
                    else if( vehicleChoice == "f")
                    {
                            fuelEfficiency = FRIEND_CAR_EFFICIENCY;
                        }
                    else
                        {
                            Console.WriteLine("Invalid vehicle choice. Deflauting to your vehicle.");
                            fuelEfficiency = YOUR_CAR_EFFICIENCY;
                        }

                        double fuelUsed = (distanceKm / 100.0) * fuelEfficiency;
                        double fuelCost = fuelUsed * gasPrice;

                    int foodCost;

                        if (distanceKm < 200)
                        {
                            foodCost = 30;
                        }
                        else if (distanceKm <= 499)
                        {
                            foodCost = 50;
                        }
                        else if (distanceKm <= 999)
                        {
                            foodCost = 80;
                        }
                        else
                        {
                            foodCost = 120;
                        }

                        double totalCost = fuelCost + foodCost;

                        Console.WriteLine("/n ----- TRip Cost Summary -----");
                        Console.WriteLine($"Trip distance: {distanceKm} Km");
                        Console.WriteLine($"Trip distance: ${gasPrice:F2} per L ");
                    Console.WriteLine($"Fuel Used: {fuelUsed:F2} L");
                        Console.WriteLine($"Fuel Cost: ${fuelCost:F2}");
                        Console.WriteLine($"Food Cost: ${foodCost}");
                        Console.WriteLine($"Total Trip Cost: ${totalCost:F2}");

                        Console.Write("/n Would you like to calculate another trip? (y/N): ");
                        string answer = Console.ReadLine().ToLower();

                        if (answer != "y")
                        {
                            continueProgram = false;
                        }
                        Console.WriteLine();
                    }
                    catch (Exception)
                    {
                    Console.WriteLine("An unexpected error has occured. Please try again");
                    }
                }
            Console.WriteLine("Program ended. Safe Travels");
            }

        }
    }
